import numpy as np,pandas as pd,matplotlib.pyplot as plt,seaborn as sns
from scipy.stats import pearsonr
import importlib.util
s=importlib.util.spec_from_file_location('cfg','00_config.py'); cfg=importlib.util.module_from_spec(s); s.loader.exec_module(cfg)
df=pd.read_csv(cfg.OUTPUT_DIR/'analysis_ready.csv'); cols=cfg.RAIN_VARS+cfg.TOPO_VARS+[cfg.SOIL_VAR]; corr=df[cols].corr(); corr.to_csv(cfg.OUTPUT_DIR/'FigS2_predictor_Pearson.csv')
y=df.log_lag.values; dlag=np.abs(y[:,None]-y[None,:]); iu=np.triu_indices(len(y),1); rows=[]; rng=np.random.default_rng(cfg.RANDOM_SEED)
for col in cols:
 x=df[col].values; x=(x-np.nanmean(x))/np.nanstd(x); dx=np.abs(x[:,None]-x[None,:]); ok=np.isfinite(dx[iu])&np.isfinite(dlag[iu]); obs=pearsonr(dlag[iu][ok],dx[iu][ok])[0]; null=[]
 for _ in range(999):
  q=rng.permutation(len(x)); null.append(pearsonr(dlag[iu][ok],dx[q][:,q][iu][ok])[0])
 p=(np.sum(np.abs(null)>=abs(obs))+1)/1000; rows.append([col,obs,p])
res=pd.DataFrame(rows,columns=['variable','Mantel_r','p_value']); res.to_csv(cfg.OUTPUT_DIR/'FigS2_Mantel_lag_only.csv',index=False)
fig,axs=plt.subplots(1,2,figsize=(11,5.5),dpi=cfg.DPI); sns.heatmap(corr,ax=axs[0],cmap='RdBu_r',vmin=-1,vmax=1,center=0,square=True,annot=True,fmt='.2f',annot_kws={'fontsize':6},cbar_kws={'label':'Pearson r'}); axs[0].set_title('A  Pearson correlations among predictors',loc='left',fontweight='bold'); axs[0].tick_params(axis='x',rotation=55,labelsize=7); r=res.Mantel_r.values; y0=np.arange(len(r)); colors=['#D73027' if p<.05 else '#BDBDBD' for p in res.p_value]; axs[1].hlines(y0,0,r,color=colors,lw=3); axs[1].scatter(r,y0,c=colors,s=35); axs[1].set_yticks(y0); axs[1].set_yticklabels([cfg.LABELS.get(x,x) for x in res.variable],fontsize=7); axs[1].set_xlabel('Mantel r'); axs[1].set_title('B  Mantel associations with log10 lag time',loc='left',fontweight='bold'); plt.tight_layout(); fig.savefig(cfg.FIGURE_DIR/'FigS2_Pearson_Mantel.pdf',bbox_inches='tight'); fig.savefig(cfg.FIGURE_DIR/'FigS2_Pearson_Mantel.png',dpi=cfg.DPI,bbox_inches='tight'); plt.close(fig)
