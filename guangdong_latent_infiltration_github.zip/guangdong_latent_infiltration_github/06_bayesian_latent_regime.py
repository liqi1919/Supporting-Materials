import json,numpy as np,pandas as pd
from pathlib import Path
from cmdstanpy import CmdStanModel
import importlib.util
s=importlib.util.spec_from_file_location('cfg','00_config.py'); cfg=importlib.util.module_from_spec(s); s.loader.exec_module(cfg)
df=pd.read_csv(cfg.OUTPUT_DIR/'analysis_ready.csv')
stan=r'''data {int<lower=1> N; int<lower=2> K; vector[N] x; vector[N] y;} parameters {vector[K-1] alpha; vector[K-1] beta; vector[K] mu; vector<lower=0>[K] sigma;} model {alpha~normal(0,2.5); beta~normal(0,2.5); mu~normal(0,5); sigma~student_t(3,0,2.5); for(i in 1:N){vector[K] eta; vector[K] lt; eta[1:(K-1)]=alpha+beta*x[i]; eta[K]=0; lt=log_softmax(eta); for(k in 1:K) target+=lt[k]+normal_lpdf(y[i]|mu[k],sigma[k]); target+=log_sum_exp(lt);}} generated quantities {vector[N] log_lik; matrix[N,K] regime_prob; for(i in 1:N){vector[K] eta; eta[1:(K-1)]=alpha+beta*x[i]; eta[K]=0; eta=log_softmax(eta); for(k in 1:K) regime_prob[i,k]=exp(eta[k]); vector[K] lt; for(k in 1:K) lt[k]=eta[k]+normal_lpdf(y[i]|mu[k],sigma[k]); log_lik[i]=log_sum_exp(lt);}}'''
# Correct marginal likelihood: target receives only log_sum_exp over mixture components.
stan=stan.replace('for(k in 1:K) target+=lt[k]+normal_lpdf(y[i]|mu[k],sigma[k]); target+=log_sum_exp(lt);','for(k in 1:K) lt[k]=lt[k]+normal_lpdf(y[i]|mu[k],sigma[k]); target+=log_sum_exp(lt);')
sp=cfg.OUTPUT_DIR/'latent_regime_model.stan'; sp.write_text(stan,encoding='utf-8'); model=CmdStanModel(stan_file=str(sp)); x=df['z_'+cfg.SOIL_VAR].values; y=df.log_lag.values
rows=[]
for K in cfg.K_CANDIDATES:
 fit=model.sample(data={'N':len(df),'K':K,'x':x,'y':y},chains=cfg.CHAINS,iter_warmup=cfg.ITER_WARMUP,iter_sampling=cfg.ITER_SAMPLING,seed=cfg.RANDOM_SEED+K,adapt_delta=cfg.TARGET_ACCEPT)
 ll=fit.stan_variable('log_lik')
 # WAIC: pointwise lppd - posterior variance of log likelihood.
 lppd=np.sum(np.log(np.mean(np.exp(ll-np.max(ll,axis=0)),axis=0))+np.max(ll,axis=0)); pwaic=np.sum(np.var(ll,axis=0,ddof=1)); waic=-2*(lppd-pwaic)
 rows.append([K,waic,lppd,pwaic,np.nanmax(np.abs(fit.summary()['R_hat'].to_numpy()-1))])
 if K==cfg.SELECTED_K:
  np.savez(cfg.OUTPUT_DIR/f'posterior_K{K}.npz',alpha=fit.stan_variable('alpha'),beta=fit.stan_variable('beta'),mu=fit.stan_variable('mu'),sigma=fit.stan_variable('sigma'),regime_prob=fit.stan_variable('regime_prob'),log_lik=ll)
  fit.summary().to_csv(cfg.OUTPUT_DIR/f'latent_regime_K{K}_summary.csv')
waic=pd.DataFrame(rows,columns=['K','WAIC','lppd','p_WAIC','max_abs_Rhat_minus_1']); waic['Delta_WAIC']=waic.WAIC-waic.WAIC.min(); waic.to_csv(cfg.OUTPUT_DIR/'WAIC_model_comparison.csv',index=False); selected=int(waic.loc[waic.WAIC.idxmin(),'K']); json.dump({'selected_K':selected},open(cfg.OUTPUT_DIR/'selected_K.json','w'),indent=2); print(waic)
