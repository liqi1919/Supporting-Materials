import numpy as np,pandas as pd,matplotlib.pyplot as plt,seaborn as sns
from scipy.stats import kruskal,levene,pearsonr
import importlib.util
spec=importlib.util.spec_from_file_location('cfg','00_config.py'); cfg=importlib.util.module_from_spec(spec); spec.loader.exec_module(cfg)
df=pd.read_csv(cfg.OUTPUT_DIR/'analysis_ready.csv'); df['soil_q']=pd.qcut(df[cfg.SOIL_VAR],4,labels=['Q1 (Thin)','Q2','Q3','Q4 (Thick)'])
g=[x.log_lag.values for _,x in df.groupby('soil_q',observed=True)]; H,pkw=kruskal(*g); W,plev=levene(*g,center='median'); print('Kruskal-Wallis:',H,pkw,'Levene:',W,plev)
def mantel_joint(response,predictor,nperm=999,seed=20260823):
 rng=np.random.default_rng(seed); response=np.asarray(response,float); predictor=np.asarray(predictor,float); ok=np.isfinite(response).all(1)&np.isfinite(predictor); response=response[ok]; predictor=predictor[ok]; response=(response-response.mean(0))/response.std(0,ddof=1); predictor=(predictor-predictor.mean())/predictor.std(ddof=1); dr=np.sqrt(((response[:,None,:]-response[None,:,:])**2).sum(2)); dp=np.abs(predictor[:,None]-predictor[None,:]); iu=np.triu_indices(len(response),1); obs=pearsonr(dr[iu],dp[iu])[0]; null=np.empty(nperm)
 for i in range(nperm):
  q=rng.permutation(len(response)); null[i]=pearsonr(dr[iu],dp[q][:,q][iu])[0]
 return obs,(np.sum(np.abs(null)>=abs(obs))+1)/(nperm+1)
fig,axs=plt.subplots(2,2,figsize=(9,7.5),dpi=cfg.DPI); A,B,C,D=axs.ravel()
sns.scatterplot(data=df,x=cfg.SOIL_VAR,y=cfg.LAG_VAR,s=20,alpha=.3,edgecolor='none',ax=A); sns.regplot(data=df,x=cfg.SOIL_VAR,y=cfg.LAG_VAR,scatter=False,color='#E66A00',ax=A); A.set(xlabel='Soil thickness (m)',ylabel='Lag time (h)',title='A  Soil thickness and lag time'); A.title.set_loc('left')
sns.violinplot(data=df,x='soil_q',y=cfg.LAG_VAR,inner='box',cut=0,linewidth=.8,ax=B); B.set(xlabel='Soil thickness quartiles',ylabel='Lag time (h)',title='B  Lag-time distributions'); B.title.set_loc('left')
sns.boxplot(data=df,x='soil_q',y=cfg.LAG_VAR,width=.55,showfliers=False,linewidth=.8,ax=C); C.text(.02,.95,f'Kruskal–Wallis P = {pkw:.2e}\nLevene P = {plev:.2f}',transform=C.transAxes,va='top',fontsize=8); C.set(xlabel='Soil thickness classes',ylabel='Lag time (h)',title='C  Group comparison'); C.title.set_loc('left')
response=df[['z_'+cfg.SOIL_VAR,'log_lag']].to_numpy(); results=[]
for col in cfg.RAIN_VARS+cfg.TOPO_VARS+[cfg.SOIL_VAR]:
 r,pp=mantel_joint(response,df[col].values); results.append([col,r,pp])
res=pd.DataFrame(results,columns=['variable','Mantel_r','p_value']); res.to_csv(cfg.OUTPUT_DIR/'Fig2D_combined_response_mantel.csv',index=False); x=np.arange(len(res)); D.bar(x,res.Mantel_r,color=['#D73027' if q<.05 else '#BDBDBD' for q in res.p_value]); D.axhline(0,color='black',lw=.7); D.set_xticks(x); D.set_xticklabels([cfg.LABELS.get(v,v) for v in res.variable],rotation=55,ha='right',fontsize=7); D.set_ylabel('Mantel r'); D.set_title('D  Joint subsurface–timing response'); D.title.set_loc('left'); D.text(.02,.96,'Response = soil thickness + log10(lag time)',transform=D.transAxes,va='top',fontsize=8)
for ax in axs.ravel(): ax.grid(True,ls='--',lw=.5,alpha=.25); ax.set_axisbelow(True)
plt.tight_layout(); fig.savefig(cfg.FIGURE_DIR/'Fig2_null_evidence.pdf',bbox_inches='tight'); fig.savefig(cfg.FIGURE_DIR/'Fig2_null_evidence.png',dpi=cfg.DPI,bbox_inches='tight'); plt.close(fig)
