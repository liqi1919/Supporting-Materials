import pandas as pd,numpy as np,matplotlib.pyplot as plt,seaborn as sns
from scipy.stats import pearsonr,spearmanr
import importlib.util
s=importlib.util.spec_from_file_location('cfg','00_config.py'); cfg=importlib.util.module_from_spec(s); s.loader.exec_module(cfg)
df=pd.read_csv(cfg.OUTPUT_DIR/'analysis_ready.csv'); cols=cfg.RAIN_VARS+cfg.TOPO_VARS+[cfg.SOIL_VAR]; fig,axs=plt.subplots(3,3,figsize=(10,10),dpi=cfg.DPI); rows=[]
for ax,col in zip(axs.ravel(),cols):
 x=df[col]; y=df.log_lag; ok=x.notna()&y.notna(); sns.regplot(x=x[ok],y=y[ok],ax=ax,scatter_kws={'s':11,'alpha':.28},line_kws={'color':'black','lw':1}); r,p=pearsonr(x[ok],y[ok]); rho,ps=spearmanr(x[ok],y[ok]); ax.text(.05,.93,f'Pearson r={r:.2f}\nP '+('<0.001' if p<.001 else f'= {p:.3f}'),transform=ax.transAxes,fontsize=7.5,va='top'); ax.set(xlabel=cfg.LABELS.get(col,col),ylabel='log10(Lag time) (h)'); rows.append([col,r,p,rho,ps])
for ax in axs.ravel()[len(cols):]: ax.axis('off')
plt.tight_layout(); fig.savefig(cfg.FIGURE_DIR/'FigS1_direct_environment_lag_relationships.pdf',bbox_inches='tight'); fig.savefig(cfg.FIGURE_DIR/'FigS1_direct_environment_lag_relationships.png',dpi=cfg.DPI,bbox_inches='tight'); plt.close(fig); pd.DataFrame(rows,columns=['variable','Pearson_r','Pearson_p','Spearman_rho','Spearman_p']).to_csv(cfg.OUTPUT_DIR/'FigS1_statistics.csv',index=False)
