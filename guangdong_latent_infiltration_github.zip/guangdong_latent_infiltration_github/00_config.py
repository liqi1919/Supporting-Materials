from pathlib import Path
DATA_FILE=Path('data/Guangdong_2010_2023_final_analysis.xlsx')
SHEET_NAME=0
OUTPUT_DIR=Path('outputs'); FIGURE_DIR=Path('figures')
OUTPUT_DIR.mkdir(exist_ok=True); FIGURE_DIR.mkdir(exist_ok=True)
RAIN_VARS=['cum_rain_3h','cum_rain_6h','cum_rain_12h','cum_rain_1d','cum_rain_2d','cum_rain_3d']
TOPO_VARS=['slope','aspect']; SOIL_VAR='soil_thickness_m'; LITHOLOGY_VAR='lithology'; LAG_VAR='lag_time_h'
LABELS={'cum_rain_3h':'3-h cumulative rainfall (mm)','cum_rain_6h':'6-h cumulative rainfall (mm)','cum_rain_12h':'12-h cumulative rainfall (mm)','cum_rain_1d':'1-d cumulative rainfall (mm)','cum_rain_2d':'2-d cumulative rainfall (mm)','cum_rain_3d':'3-d cumulative rainfall (mm)','slope':'Slope (°)','aspect':'Aspect (°)','soil_thickness_m':'Soil thickness (m)','lag_time_h':'Lag time (h)','log_lag':'log10(Lag time) (h)'}
LITHOLOGY_EN={'火山碎屑岩':'Pyroclastic rocks','松散沉积物':'Unconsolidated sediments','花岗岩类':'Granitoids','红层软岩':'Red-bed soft rocks','混合岩类':'Migmatites','变质岩类':'Metamorphic rocks','碳酸盐岩':'Carbonate rocks','其他岩类':'Other lithologies'}
RANDOM_SEED=20260823; K_CANDIDATES=range(2,9); SELECTED_K=6; CHAINS=4; ITER_WARMUP=5000; ITER_SAMPLING=5000; TARGET_ACCEPT=.90
RF_N_ESTIMATORS=500; RF_MAX_DEPTH=20; RF_MIN_SAMPLES_SPLIT=2; RF_MIN_SAMPLES_LEAF=2; RF_MAX_FEATURES='sqrt'; RF_BOOTSTRAP=False
XGB_N_ESTIMATORS=500; XGB_MAX_DEPTH=6; XGB_LEARNING_RATE=.03; XGB_SUBSAMPLE=.8; XGB_COLSAMPLE_BYTREE=.8
DPI=600; FONT='Arial'
