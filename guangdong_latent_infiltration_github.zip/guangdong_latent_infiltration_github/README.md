# Latent infiltration regimes mediate environmental controls on delayed rainfall-induced landslides

Reproducible Python workflow for the Guangdong rainfall-induced landslide study.

## Execution order

```bash
python 01_prepare_data.py
python 02_fig1_pca_environment.py
python 03_fig2_null_evidence.py
python 04_figS1_rainfall_lag.py
python 05_figS2_pearson_mantel.py
python 06_bayesian_latent_regime.py
python 07_regime_posterior_transition.py
python 08_regime_environmental_statistics.py
python 09_ml_rf_xgboost_shap.py
python 10_fig_regime_signatures.py
python 11_table_S1_representative_landslides.py
python 12_reproducibility_report.py
```

The raw inventory is not included by default. Place the authorized source file at `data/Guangdong_2010_2023_final_analysis.xlsx` and edit `00_config.py` if field names differ.

For Table S1, fill `data/representative_zone_points.csv` with the exact longitude/latitude of the 12 numbered locations in Fig. 1B. The script then selects the nearest inventory landslide using a haversine BallTree search.

The Bayesian model infers latent regimes from log-transformed lag times using a finite Gaussian mixture. Regime probabilities depend on standardized soil thickness. Discrete states are analytically marginalized. Candidate K values are compared with WAIC; K=6 is reported when it is the selected model.

RF, XGBoost and SHAP are strictly post-Bayesian interpretive analyses and do not affect regime estimation.
