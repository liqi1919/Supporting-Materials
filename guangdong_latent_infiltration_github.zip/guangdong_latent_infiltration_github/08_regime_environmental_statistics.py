import numpy as np,pandas as pd,matplotlib.pyplot as plt
from scipy import stats
from statsmodels.stats.multitest import multipletests
import importlib.util
s=importlib.util.spec_from_file_location('cfg','00_config.py'); cfg=importlib.util.module_from_spec(s); s.loader.exec_module(cfg)
df=pd.read_csv(cfg.OUTPUT_DIR/'posterior_regime_assignments.csv'); rc='dominant_regime'; regs=sorted(df[rc].unique()); feats=cfg.RAIN_VARS+cfg.TOPO_VARS+[cfg.SOIL_VAR]; rows=[]
for f in feats:
 g=[df.loc[df[rc]==r,f].dropna().values for r in regs]; H,p=stats.kruskal(*g); rows.append([f,H,p])
r=pd.DataFrame(rows,columns=['feature','H','p']); r['p_FDR']=multipletests(r.p,method='fdr_bh')[1]; r.to_csv(cfg.OUTPUT_DIR/'regime_environmental_KW.csv',index=False)
ref='Regime A' if 'Regime A' in regs else regs[0]; v=[]
for f in feats:
 a=df.loc[df[rc]==ref,f].dropna()
 for reg in regs:
  if reg==ref: continue
  b=df.loc[df[rc]==reg,f].dropna(); p=stats.mannwhitneyu(a,b,alternative='two-sided').pvalue; ma=a.mean(); mb=b.mean(); fc=np.log2(mb/ma) if ma>0 and mb>0 else np.nan; v.append([f,reg,fc,p])
v=pd.DataFrame(v,columns=['feature','regime','log2FC','p']); v['p_FDR']=multipletests(v.p,method='fdr_bh')[1]; v['minus_log10_p']=-np.log10(np.maximum(v.p_FDR,1e-300)); v.to_csv(cfg.OUTPUT_DIR/'regime_environmental_volcano.csv',index=False)
fig,ax=plt.subplots(figsize=(6,5),dpi=cfg.DPI); sig=v.p_FDR<.05; ax.scatter(v.loc[~sig,'log2FC'],v.loc[~sig,'minus_log10_p'],s=25,alpha=.45); ax.scatter(v.loc[sig,'log2FC'],v.loc[sig,'minus_log10_p'],s=35,alpha=.8); ax.axhline(-np.log10(.05),color='gray',ls='--',lw=.8); ax.axvline(0,color='gray',lw=.8); ax.set(xlabel='log2 fold change vs. reference regime',ylabel='-log10(FDR-adjusted P)'); plt.tight_layout(); fig.savefig(cfg.FIGURE_DIR/'Fig_regime_environmental_volcano.pdf',bbox_inches='tight'); fig.savefig(cfg.FIGURE_DIR/'Fig_regime_environmental_volcano.png',dpi=cfg.DPI,bbox_inches='tight'); plt.close(fig)
