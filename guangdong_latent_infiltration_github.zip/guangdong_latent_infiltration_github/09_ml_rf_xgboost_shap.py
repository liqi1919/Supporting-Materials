import numpy as np,pandas as pd,matplotlib.pyplot as plt
from sklearn.model_selection import StratifiedKFold,cross_val_score
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
import shap
import importlib.util
s=importlib.util.spec_from_file_location('cfg','00_config.py'); cfg=importlib.util.module_from_spec(s); s.loader.exec_module(cfg)
df=pd.read_csv(cfg.OUTPUT_DIR/'posterior_regime_assignments.csv'); feats=cfg.RAIN_VARS+cfg.TOPO_VARS+[cfg.SOIL_VAR]; X=df[feats]; y=df.dominant_regime.astype('category').cat.codes; cv=StratifiedKFold(5,shuffle=True,random_state=cfg.RANDOM_SEED)
rf=RandomForestClassifier(n_estimators=cfg.RF_N_ESTIMATORS,max_depth=cfg.RF_MAX_DEPTH,min_samples_split=cfg.RF_MIN_SAMPLES_SPLIT,min_samples_leaf=cfg.RF_MIN_SAMPLES_LEAF,max_features=cfg.RF_MAX_FEATURES,bootstrap=cfg.RF_BOOTSTRAP,random_state=cfg.RANDOM_SEED,n_jobs=-1,class_weight='balanced_subsample'); rs=cross_val_score(rf,X,y,cv=cv,scoring='balanced_accuracy'); rf.fit(X,y); pd.DataFrame({'feature':feats,'importance':rf.feature_importances_}).sort_values('importance',ascending=False).to_csv(cfg.OUTPUT_DIR/'RF_feature_importance.csv',index=False)
xgb=XGBClassifier(n_estimators=cfg.XGB_N_ESTIMATORS,max_depth=cfg.XGB_MAX_DEPTH,learning_rate=cfg.XGB_LEARNING_RATE,subsample=cfg.XGB_SUBSAMPLE,colsample_bytree=cfg.XGB_COLSAMPLE_BYTREE,objective='multi:softprob',eval_metric='mlogloss',random_state=cfg.RANDOM_SEED,n_jobs=-1); xs=cross_val_score(xgb,X,y,cv=cv,scoring='balanced_accuracy'); xgb.fit(X,y); pd.DataFrame({'feature':feats,'importance':xgb.feature_importances_}).sort_values('importance',ascending=False).to_csv(cfg.OUTPUT_DIR/'XGBoost_feature_importance.csv',index=False)
explainer=shap.TreeExplainer(xgb); sv=explainer.shap_values(X)
arr=np.asarray(sv); meanabs=np.abs(arr).mean(axis=tuple(i for i in range(arr.ndim) if i!=1)); pd.DataFrame({'feature':feats,'mean_abs_SHAP':meanabs}).sort_values('mean_abs_SHAP',ascending=False).to_csv(cfg.OUTPUT_DIR/'SHAP_global_importance.csv',index=False)
shap.summary_plot(sv,X,show=False,plot_size=(7,5)); plt.tight_layout(); plt.savefig(cfg.FIGURE_DIR/'SHAP_summary_XGBoost.pdf',bbox_inches='tight'); plt.savefig(cfg.FIGURE_DIR/'SHAP_summary_XGBoost.png',dpi=cfg.DPI,bbox_inches='tight'); plt.close(); print('RF balanced accuracy:',rs.mean(),rs.std()); print('XGB balanced accuracy:',xs.mean(),xs.std())
