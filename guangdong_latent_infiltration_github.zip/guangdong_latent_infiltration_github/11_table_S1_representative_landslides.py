import numpy as np,pandas as pd
from pathlib import Path
from sklearn.neighbors import BallTree
import importlib.util
s=importlib.util.spec_from_file_location('cfg','00_config.py'); cfg=importlib.util.module_from_spec(s); s.loader.exec_module(cfg)
inv=pd.read_csv(cfg.OUTPUT_DIR/'analysis_ready.csv'); pf=Path('data/representative_zone_points.csv')
if not pf.exists():
 pd.DataFrame({'zone_id':range(1,13),'zone_name':['']*12,'longitude':[np.nan]*12,'latitude':[np.nan]*12}).to_csv(pf,index=False,encoding='utf-8-sig'); raise FileNotFoundError('Fill data/representative_zone_points.csv with exact map coordinates and rerun.')
z=pd.read_csv(pf); need=['zone_id','zone_name','longitude','latitude']; missing=[c for c in need if c not in z];
if missing: raise KeyError(missing)
tree=BallTree(np.deg2rad(inv[['latitude','longitude']].values),metric='haversine'); dist,idx=tree.query(np.deg2rad(z[['latitude','longitude']].values),k=1); sel=inv.iloc[idx[:,0]].copy(); out=z.copy(); out['nearest_inventory_id']=sel.analysis_id.values; out['distance_to_mapped_landslide_km']=dist[:,0]*6371.0088
for c in ['lag_time_h','log_lag','cum_rain_3h','cum_rain_6h','cum_rain_12h','cum_rain_1d','cum_rain_2d','cum_rain_3d','slope','aspect','soil_thickness_m','lithology_en','latitude','longitude']:
 if c in sel: out[c]=sel[c].values
out=out.rename(columns={'zone_id':'Representative zone','zone_name':'Mountainous region','longitude':'Longitude (°E)','latitude':'Latitude (°N)','lag_time_h':'Lag time (h)','log_lag':'log10(Lag time)','cum_rain_3h':'3-h rainfall (mm)','cum_rain_6h':'6-h rainfall (mm)','cum_rain_12h':'12-h rainfall (mm)','cum_rain_1d':'1-d rainfall (mm)','cum_rain_2d':'2-d rainfall (mm)','cum_rain_3d':'3-d rainfall (mm)','slope':'Slope (°)','aspect':'Aspect (°)','soil_thickness_m':'Soil thickness (m)','lithology_en':'Lithology'})
out.to_excel(cfg.OUTPUT_DIR/'Table_S1_representative_landslides.xlsx',index=False); out.to_csv(cfg.OUTPUT_DIR/'Table_S1_representative_landslides.csv',index=False,encoding='utf-8-sig'); print(out.to_string(index=False))
