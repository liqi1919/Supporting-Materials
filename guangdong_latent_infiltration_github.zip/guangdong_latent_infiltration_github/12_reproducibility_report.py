from pathlib import Path
import sys,platform,pandas as pd,importlib.util
s=importlib.util.spec_from_file_location('cfg','00_config.py'); cfg=importlib.util.module_from_spec(s); s.loader.exec_module(cfg)
r=['Guangdong latent infiltration-regime reproducibility report','='*65,f'Python: {sys.version}',f'Platform: {platform.platform()}']; df=pd.read_csv(cfg.OUTPUT_DIR/'analysis_ready.csv'); r += [f'Analysis-ready samples: {len(df)}',f'Lag-time range (h): {df[cfg.LAG_VAR].min():.6g} - {df[cfg.LAG_VAR].max():.6g}']; w=cfg.OUTPUT_DIR/'WAIC_model_comparison.csv';
if w.exists(): r += ['','WAIC comparison:',pd.read_csv(w).to_string(index=False)]; q=cfg.OUTPUT_DIR/'posterior_regime_assignments.csv'
if q.exists(): r += ['','Regime counts:',pd.read_csv(q).dominant_regime.value_counts().sort_index().to_string()]
Path(cfg.OUTPUT_DIR/'reproducibility_report.txt').write_text('\n'.join(r),encoding='utf-8'); print('\n'.join(r))
