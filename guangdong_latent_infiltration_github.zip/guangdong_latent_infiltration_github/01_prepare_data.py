import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler
import importlib.util
spec=importlib.util.spec_from_file_location('cfg','00_config.py'); cfg=importlib.util.module_from_spec(spec); spec.loader.exec_module(cfg)
df=pd.read_excel(cfg.DATA_FILE,sheet_name=cfg.SHEET_NAME)
required=cfg.RAIN_VARS+cfg.TOPO_VARS+[cfg.SOIL_VAR,cfg.LITHOLOGY_VAR,cfg.LAG_VAR]
missing=[c for c in required if c not in df.columns]
if missing: raise KeyError('Missing required columns: '+', '.join(missing))
for c in cfg.RAIN_VARS+cfg.TOPO_VARS+[cfg.SOIL_VAR,cfg.LAG_VAR]: df[c]=pd.to_numeric(df[c],errors='coerce')
df=df[df[cfg.LAG_VAR]>0].copy(); df['log_lag']=np.log10(df[cfg.LAG_VAR])
df['lithology_en']=df[cfg.LITHOLOGY_VAR].map(cfg.LITHOLOGY_EN).fillna(df[cfg.LITHOLOGY_VAR].astype(str))
cols=cfg.RAIN_VARS+cfg.TOPO_VARS+[cfg.SOIL_VAR,cfg.LITHOLOGY_VAR,cfg.LAG_VAR]
df=df.dropna(subset=cols).copy(); scaler=StandardScaler()
cont=cfg.RAIN_VARS+cfg.TOPO_VARS+[cfg.SOIL_VAR]; df[['z_'+c for c in cont]]=scaler.fit_transform(df[cont])
df.insert(0,'analysis_id',np.arange(1,len(df)+1)); df.to_csv(cfg.OUTPUT_DIR/'analysis_ready.csv',index=False,encoding='utf-8-sig')
print('Analysis-ready samples:',len(df)); print('Columns:',list(df.columns))
