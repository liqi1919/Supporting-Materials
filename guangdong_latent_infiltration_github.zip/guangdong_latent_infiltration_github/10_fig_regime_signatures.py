import pandas as pd,matplotlib.pyplot as plt,seaborn as sns
import importlib.util
s=importlib.util.spec_from_file_location('cfg','00_config.py'); cfg=importlib.util.module_from_spec(s); s.loader.exec_module(cfg)
df=pd.read_csv(cfg.OUTPUT_DIR/'posterior_regime_assignments.csv'); regs=sorted(df.dominant_regime.unique()); fig,axs=plt.subplots(2,2,figsize=(9,7),dpi=cfg.DPI); A,B,C,D=axs.ravel()
sns.violinplot(data=df,x='dominant_regime',y='log_lag',order=regs,inner='box',cut=0,linewidth=.8,ax=A); A.set(xlabel='',ylabel='log10(Lag time) (h)',title='A  Temporal signatures of inferred regimes'); A.title.set_loc('left')
for r in regs: sns.regplot(data=df,x=cfg.SOIL_VAR,y=r,lowess=True,scatter=False,line_kws={'lw':1.8},ax=B)
B.set(xlabel='Soil thickness (m)',ylabel='Posterior regime probability',ylim=(0,1),title='B  Regime probabilities along soil-thickness gradient'); B.title.set_loc('left')
C.scatter(df[cfg.SOIL_VAR],df.regime_entropy,s=16,alpha=.35); C.set(xlabel='Soil thickness (m)',ylabel='Regime uncertainty (entropy)',title='C  Transition-zone uncertainty'); C.title.set_loc('left')
f=cfg.OUTPUT_DIR/'SHAP_global_importance.csv'
if f.exists(): q=pd.read_csv(f).sort_values('mean_abs_SHAP'); D.barh(q.feature,q.mean_abs_SHAP); D.set(xlabel='Mean |SHAP|',ylabel='',title='D  Environmental attribution')
for ax in axs.ravel(): ax.grid(True,ls='--',lw=.5,alpha=.25); ax.set_axisbelow(True)
plt.tight_layout(); fig.savefig(cfg.FIGURE_DIR/'Regime_results_summary.pdf',bbox_inches='tight'); fig.savefig(cfg.FIGURE_DIR/'Regime_results_summary.png',dpi=cfg.DPI,bbox_inches='tight'); plt.close(fig)
