import json,numpy as np,pandas as pd,matplotlib.pyplot as plt
from scipy.special import softmax
import importlib.util
s=importlib.util.spec_from_file_location('cfg','00_config.py'); cfg=importlib.util.module_from_spec(s); s.loader.exec_module(cfg)
df=pd.read_csv(cfg.OUTPUT_DIR/'analysis_ready.csv'); K=json.load(open(cfg.OUTPUT_DIR/'selected_K.json'))['selected_K']; z=np.load(cfg.OUTPUT_DIR/f'posterior_K{K}.npz'); alpha,beta,mu=z['alpha'],z['beta'],z['mu']; order=np.argsort(mu.mean(0)); labs=[f'Regime {chr(65+i)}' for i in range(K)]; x=df['z_'+cfg.SOIL_VAR].values; S=alpha.shape[0]
P=np.zeros((len(df),K))
for i,xi in enumerate(x):
 eta=np.zeros((S,K)); eta[:,:K-1]=alpha+beta*xi; P[i]=softmax(eta,axis=1).mean(0)[order]
for j,lab in enumerate(labs): df[lab]=P[:,j]
df['dominant_regime']=np.array(labs)[np.argmax(P,axis=1)]; df['regime_entropy']=-(P*np.log(P+1e-12)).sum(1); df.to_csv(cfg.OUTPUT_DIR/'posterior_regime_assignments.csv',index=False)
raw=np.linspace(df[cfg.SOIL_VAR].quantile(.01),df[cfg.SOIL_VAR].quantile(.99),200); zraw=(raw-df[cfg.SOIL_VAR].mean())/df[cfg.SOIL_VAR].std(ddof=1); C=[]
for xi in zraw:
 eta=np.zeros((S,K)); eta[:,:K-1]=alpha+beta*xi; C.append(softmax(eta,axis=1).mean(0)[order])
C=np.array(C); fig,ax=plt.subplots(figsize=(6,4.5),dpi=cfg.DPI)
for j,l in enumerate(labs): ax.plot(raw,C[:,j],lw=2,label=l)
ax.set(xlabel='Soil thickness (m)',ylabel='Posterior regime probability',ylim=(0,1)); ax.grid(True,ls='--',alpha=.3); ax.legend(frameon=False,ncol=2); plt.tight_layout(); fig.savefig(cfg.FIGURE_DIR/'Fig_regime_probability_vs_soil_thickness.pdf',bbox_inches='tight'); fig.savefig(cfg.FIGURE_DIR/'Fig_regime_probability_vs_soil_thickness.png',dpi=cfg.DPI,bbox_inches='tight'); plt.close(fig)
fig,ax=plt.subplots(figsize=(6,4.5),dpi=cfg.DPI); ax.scatter(df[cfg.SOIL_VAR],df.regime_entropy,s=15,alpha=.35); ax.set(xlabel='Soil thickness (m)',ylabel='Regime uncertainty (entropy)'); ax.grid(True,ls='--',alpha=.3); plt.tight_layout(); fig.savefig(cfg.FIGURE_DIR/'Fig_regime_uncertainty.pdf',bbox_inches='tight'); fig.savefig(cfg.FIGURE_DIR/'Fig_regime_uncertainty.png',dpi=cfg.DPI,bbox_inches='tight'); plt.close(fig)
print(pd.Series(mu.mean(0)[order],index=labs))
