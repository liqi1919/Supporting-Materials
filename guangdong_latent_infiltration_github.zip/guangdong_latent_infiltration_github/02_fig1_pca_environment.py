import numpy as np,pandas as pd,matplotlib.pyplot as plt,matplotlib as mpl,seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from scipy.stats import pearsonr
import importlib.util
spec=importlib.util.spec_from_file_location('cfg','00_config.py'); cfg=importlib.util.module_from_spec(spec); spec.loader.exec_module(cfg)
df=pd.read_csv(cfg.OUTPUT_DIR/'analysis_ready.csv'); cont=cfg.RAIN_VARS+cfg.TOPO_VARS+[cfg.SOIL_VAR]
lith=pd.get_dummies(df['lithology_en'],prefix='Lithology',dtype=float); X=pd.concat([df[cont],lith],axis=1)
X=StandardScaler().fit_transform(X); pca=PCA(2,random_state=cfg.RANDOM_SEED); pc=pca.fit_transform(X); ev=pca.explained_variance_ratio_*100
p=pd.DataFrame(pc,columns=['PC1','PC2']); p['log_lag']=df.log_lag.values
mpl.rcParams.update({'font.family':cfg.FONT,'font.size':9,'pdf.fonttype':42,'ps.fonttype':42})
fig,axs=plt.subplots(2,2,figsize=(9,8),dpi=cfg.DPI); a,b,c,d=axs.ravel()
sc=a.scatter(p.PC1,p.PC2,c=p.log_lag,cmap='viridis',s=22,alpha=.72,edgecolors='none'); cb=fig.colorbar(sc,ax=a,fraction=.046,pad=.04); cb.set_label('log10(Lag time) (h)',fontsize=8)
load=pca.components_.T; names=list(pd.concat([df[cont],lith],axis=1).columns); scale=3
for i,n in enumerate(names):
 l1,l2=load[i];
 if abs(l1)<.2 and abs(l2)<.2: continue
 label=n.replace('cum_rain_','').replace('_','') if n.startswith('cum_rain_') else ('Soil thickness' if n=='soil_thickness_m' else ('Lithology: '+n.replace('Lithology_','') if n.startswith('Lithology_') else n.title()))
 x,y=l1*scale,l2*scale; a.annotate('',xy=(x,y),xytext=(0,0),arrowprops=dict(arrowstyle='-|>',lw=1,color='black',alpha=.65)); a.text(x+.08*np.sign(x if x else 1),y+.06*np.sign(y if y else 1),label,fontsize=7,ha='left' if x>=0 else 'right')
a.axhline(0,color='gray',lw=.5,ls='--'); a.axvline(0,color='gray',lw=.5,ls='--'); a.set(xlabel=f'PC1 ({ev[0]:.1f}%)',ylabel=f'PC2 ({ev[1]:.1f}%)',title='C  Environmental control space'); a.title.set_loc('left')
def reg(ax,x,y,ylabel,title,xlabel):
 sns.regplot(x=x,y=y,ax=ax,scatter_kws={'s':18,'alpha':.35,'color':'#2C7BB6'},line_kws={'color':'black','lw':1.15}); r,pp=pearsonr(x,y); ax.text(.05,.92,f'R² = {r*r:.2f}\np '+('< 0.001' if pp<.001 else f'= {pp:.3f}'),transform=ax.transAxes,fontsize=8,va='top'); ax.set(xlabel=xlabel,ylabel=ylabel,title=title); ax.title.set_loc('left')
reg(b,p.PC1,df.cum_rain_3h,cfg.LABELS['cum_rain_3h'],'D  Rainfall forcing','PC1'); reg(c,p.PC2,df[cfg.SOIL_VAR],cfg.LABELS[cfg.SOIL_VAR],'E  Subsurface gradient','PC2')
sns.regplot(x=p.PC2,y=p.log_lag,ax=d,scatter_kws={'s':18,'alpha':.35,'color':'#4D4D4D'},line_kws={'color':'black','lw':1.15}); r,pp=pearsonr(p.PC2,p.log_lag); d.text(.05,.92,f'R² = {r*r:.2f}\np '+('< 0.001' if pp<.001 else f'= {pp:.3f}'),transform=d.transAxes,fontsize=8,va='top'); d.set(xlabel='PC2',ylabel='log10(Lag time) (h)',title='F  Lag-time response'); d.title.set_loc('left')
for ax in axs.ravel(): ax.grid(True,ls='--',lw=.5,alpha=.3); ax.set_axisbelow(True)
plt.tight_layout(); fig.savefig(cfg.FIGURE_DIR/'Fig1C_F_environmental_control_space.pdf',bbox_inches='tight'); fig.savefig(cfg.FIGURE_DIR/'Fig1C_F_environmental_control_space.png',dpi=cfg.DPI,bbox_inches='tight'); plt.close(fig)
pd.DataFrame(load,index=names,columns=['PC1','PC2']).to_csv(cfg.OUTPUT_DIR/'PCA_loadings.csv')
